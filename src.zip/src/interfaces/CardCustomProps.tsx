export default interface CardCustomProps {
  title: string;
  image?: string;
  desc: string;
}
